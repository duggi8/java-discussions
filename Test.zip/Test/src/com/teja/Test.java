package com.teja;

public class Test {

	public static void main(String[] args) {
		
		Car duster = new Car(); 
//reference type Car, reference variable 'duster', Constructor -->new Car();		
		
	//	'duster' is an instance of class Car
	    
		String col = duster.colour;
		
	   duster.changeTheGear(); //
	
		duster.getTheGear();
		
		
		Car swift = new Car();
	    
	    
	    Car bollero = new Car();
	    
		
	}

}
