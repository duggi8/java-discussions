package com.teja;

class Car {   //public is called 'access modifier'.

	/*//there is a car,computer,baloon,chair,table
    
* class is like blueprint. 
* 
* variables,methods.
*
*/	
	//every object has state and behavior
	//state can be like name of the car,color of the car etc-->represented by fields,variables in our class(blueprint)
	//behavior -change the gear,increase the speed---> represented by methods in our class(blueprint)
	
	//state
	String colour = "blue";
	String name = "swift";
	int noOfWheels = 4;
	int gear = 5;
	int gear1;
	
	void changeTheGear(){  //local variables--they are local to the method.they die inside the method.
		int gear1 = 1;
		System.out.println("I changed the gear" + gear1);
	}
	
	int getTheGear(){
		
		System.out.println("gear is " + this.gear);
		return this.gear;
		
	}
	
	


}
