package com.teja;

public class Human {

	String emotion; // default gets 'null' value
	boolean happiness; // default gets -->false
	String name; // null
	int height;
	int weight;
	int age;

	static String gym = "planetfitness";

	public void eat() {

		System.out.println("i am eating");
	}

	public void sleep() {
		System.out.println("I am sleeping");
	}

	public void playSoccer() {
		System.out.println("playing soccer");
	}

	public static void main(String[] args) {

		Human teja = new Human();
		teja.playSoccer();

	}

	// variables

	// instance variables,class variables,local variables,
	// the real object in memory which we create from our class.-->instance
	//

}
